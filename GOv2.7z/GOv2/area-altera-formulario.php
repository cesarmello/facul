<?php 
	$tituloPage = "Guia de Parcerias Aussel | Página em Branco";
	include 'cabecalho.php' 
    require_once ('banco-area.php');
    require_once ('logica-usuario.php');
    verificaUsuario();

    $id = $_GET['id'];
    $area = buscaArea($conexao,$id);
?>

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Alterando Área
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.php">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Blank Page
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <form action="altera-area.php" method="post">
                          <input type="hidden" name="id" value="<?=$area['id_area']?>">
                          <table class="table">
                            <?php require_once ('area-formulario-base.php');?>
                            </tr>
                            <tr> 
                              <td colspan="2"><input type="submit" value="Alterar" class="btn btn-primary" /></td>
                            </tr>
                          </table>
                        </form>
                    </div>
                </div>

              <?php include 'rodape.php' ?>
