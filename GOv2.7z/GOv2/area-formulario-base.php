		<tr>
			<td>Nome</td>
			<td><input type="text" name="nome" value="<?=$area['nome']?>" class="form-control"/></td>
		</tr>