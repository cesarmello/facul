<?php
	$conexao = mysqli_connect('localhost','root','','ausse624_dbguia');