<?php
require_once ('logica-usuario.php');
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

	<meta charset="utf-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Guia de Parcerias Aussel - Este é o sistema de gerenciamento das parcerias médicas do Sistema de Parcerias Aussel">
	<meta name="author" content="Marketing Aussel">

	<title>GUIA DE PARCERIAS AUSSEL &rsaquo; Login</title>
	<!-- Bootstrap Core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="css/sb-admin.css" rel="stylesheet">
	<!-- Morris Charts CSS -->
	<link href="css/plugins/morris.css" rel="stylesheet">
	<!-- Custom Fonts -->
	<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body class="login login-action-login wp-core-ui  locale-pt-br">
	<div id="login">
		<h1></h1>

		<?php if (usuarioEstaLogado()) { ?>
			<!-- LOGIN ERROR -->
			<div id="login_error" style="text-align:center">
				<strong>VOCÊ JÁ ESTÁ LOGADO COMO:</strong><br />
				<h2><strong><?=usuarioLogado() ?></strong></h2>
				<p><a href="logout.php">Sair</a></p>
				<br>
			</div>
		<?php } else { ?>

		<form name="loginform" id="loginform" action="login.php" method="post">
			<p>
				<label for="user_login">Nome de Usuário<br />
					<input type="text" name="email" id="user_login" class="input" value="" size="20" /></label>
				</p>
				<p>
					<label for="user_pass">Senha<br />
						<input type="password" name="senha" id="user_pass" class="input" value="" size="20" /></label>
					</p>
					<p class="submit">
						<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Entrar" />
						<!--input type="hidden" name="redirect_to" value="http://dekmidia.com.br/wp-admin/" /-->
						<input type="hidden" name="testcookie" value="1" />
					</p>
				</form>
				<?php } ?>
			</div>
			<div class="clear"></div>
		</body>
		</html>
