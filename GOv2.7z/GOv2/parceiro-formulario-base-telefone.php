		<tr>
			<td>Telefone</td>
			<td><input type="text" name="telefone" value="<?=$telefone['telefone']?>" class="form-control" onkeypress="mascara(this, mnum);"  maxlength="11"/></td>
		</tr>
